package ourCode;

public class Athlete {

	public String firstName;
	public String lastName;

	public int ID;

	public Athlete() {

	}

}
