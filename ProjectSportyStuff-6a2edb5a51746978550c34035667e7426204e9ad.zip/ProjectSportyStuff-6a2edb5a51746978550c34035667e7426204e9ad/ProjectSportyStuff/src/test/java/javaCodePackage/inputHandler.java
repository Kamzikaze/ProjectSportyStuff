package javaCodePackage;

import java.util.Scanner;

public class inputHandler {

	String inputText;
	Scanner scan;

	public inputHandler() {
		inputText = "";

	}

}
