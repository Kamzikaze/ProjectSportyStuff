package stepDefinitions;

import io.cucumber.java.en.Given;

public class General {


	//@Given("the user enters the program")
	//public void the_user_enters_the_program() {
	//	// TODO
	//}
	

	@Given("the user enters the program")
	public void the_user_enters_the_program() {
		// TODO
	}


	@Given("That I am logged in with {int} as unique ID")
	public void that_i_am_logged_in_with_as_unique_id(int uniqueID) {
		// TODO
	}

	@Given("I am on the results page")
	public void i_am_on_the_results_page() {
		// TODO
	}
}