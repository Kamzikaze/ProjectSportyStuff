package stepDefinitions;

import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class ScoreTable {

	@When("I enter a {string} value")
	public void i_enter_a_value(String value) {
		// TODO
	}

	@When("I press the save button")
	public void i_press_the_save_button() {
		// TODO
	}

	@Then("I should receive a {string} message")
	public void i_should_receive_a_message(String message) {
		// TODO
	}

	@Then("I should receive the result in IAAF format")
	public void i_should_receive_the_result_in_iaaf_format() {
		// TODO
	}
}
